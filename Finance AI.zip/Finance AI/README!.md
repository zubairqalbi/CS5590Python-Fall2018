

##Kindly refer to the StockPredictionModelv3.ipynb file for the detailed explaination and results

## Goal
For this use case you need to build a text classification system to categorize news articles containing references to a list of companies and predict the impact of the news on the stock price.

## Stock Market Price Prediction with New Data

##Using the dataset :

1.    News data: news data crawled from Reddit. They are ranked by reddit users' votes, and only the top 25 headlines are considered for a single date. (Range: 2008-06-08 to 2016-07-01)
2.    Stock data: Dow Jones Industrial Average (DJIA) is used to "prove the concept". (Range: 2008-08-08 to 2016-07-01)
Three data files are available in .csv format:
1.    RedditNews.csv: two columns. The first column is the "date", and second column is the "news headlines". All news are ranked from top to bottom based on how hot they are. Hence, there are 25 lines for each date.
2.    DJIA_table.csv: Downloaded directly from Yahoo Finance
3.    Combined_News_DJIA.csv: There are 27 columns. The first column is "Date", the second is "Label", and the following ones are news headlines ranging from "Top1" to "Top25".

"1" when DJIA Adj Close value rose or stayed as the same;
"0" when DJIA Adj Close value decreased.
Dataset:
Kaggle Dataset : https://www.kaggle.com/aaron7sun/stocknews


## Findings:

LDA seemed to be performing good with an accuracy of 94% and a precision of 0.94, but it seemed a little fishy and when checked the ROC AUC score, it turned out to be 0.5 making the model worthless. However, I still plan to simulate the model and use LDA to see the prediction and if it works well.

There are other models XGBoost and Random Forests, which are giving an accuracy of 58%, which can still be considered because it is giving a more than 50% probability of predicting the stock prices. These models will also be used in simulation for prediction.

## Reference:

##Sentence_Polarity file folder is referenced by the following algorithm for sentiment analysising.
Modified algorithm : https://github.com/ShreyamsJain/Stock-Price-Prediction-Model/blob/master/Sentence_Polarity/sentiment.py 


